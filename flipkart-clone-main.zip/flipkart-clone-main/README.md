# flipkart-clone

<h3>This is a Individual Project, I have cloned this website with using React & Redux </h3>

<h4>
<li>1. live link --> https://flipkart-clone-phi.vercel.app/</li>
<li>2. Choose MobileCategory for sample data. </li>
<li>3. Choose any particular Mobile</li>
<li>4. You can click on add to cart button.</li>
<li>5. You can click on Cart Icon on navbar and check items which are added to cart </li>
</h4>

<h3>Currently Working On - login, signin, filter, sort !!!</h3>



## Screenshots
<kbd>![Screenshot (324)](https://user-images.githubusercontent.com/97458144/187201200-3c45942a-4175-49d2-9905-07cd8a479bae.png)</kbd>
<kbd>![Screenshot (325)](https://user-images.githubusercontent.com/97458144/187200926-099834b8-1ffa-4550-b52f-928ddc13fff0.png)</kbd>
<kbd>![Screenshot (326)](https://user-images.githubusercontent.com/97458144/187201802-f22ebbcb-66a7-4e0e-a496-a9c8d2af09e6.png)
</kbd>
<kbd![Screenshot (327)](https://user-images.githubusercontent.com/97458144/187201828-40ab9db1-ab5a-4d71-8835-ccc0e52739e7.png)
></kbd>


Copyright - Ayaz Ahmad © 
