export const todayDeal = [
    {
        img : "https://m.media-amazon.com/images/I/41Diz41FkhL._AC_SY200_.jpg",
        discount : 32,
        DealOfDay : "Deal of the Day",
        desc : " Grand Gaming Days offers on Bestselling Gaming Laptops & Desktops - Exchange & No Cost EMI Available"
    },
    {
        img : "https://m.media-amazon.com/images/I/41DjFnGQ1FL._AC_SY200_.jpg",
        discount : 31,
        DealOfDay : "Deal of the Day",
        desc : "High Performance Handpicked Desktop Computers from HP, Lenovo and more"
    },
    {
        img : "https://m.media-amazon.com/images/I/31aNgbvYJKL._AC_SY200_.jpg",
        discount : 66,
        DealOfDay : "Deal of the Day",
        desc : "Best Prices on boAt Headphones, Soundbars and Speakers"
    },
    {
        img : "https://m.media-amazon.com/images/I/31G1NouVxaL._AC_SY200_.jpg",
        discount : 80,
        DealOfDay : "Deal of the Day",
        desc : "Jaw dropping deals on headsets"
    },

    {
        img : "https://m.media-amazon.com/images/I/31EXkIBVKUL._AC_SY200_.jpg",
        discount : 50,
        DealOfDay : "Deal of the Day",
        desc : "adidas & campus Footwear"
    },
    {
        img : "https://m.media-amazon.com/images/I/416x-scGWgL._AC_SY200_.jpg",
        discount : 64,
        DealOfDay : "Deal of the Day",
        desc : "Grand Gaming Days Offers on Accessories and Storage Devices"
    },

    {
        img : "https://m.media-amazon.com/images/I/31VfkewLnlL._AC_SY200_.jpg",
        discount : 54,
        DealOfDay : "Deal of the Day",
        desc : "cooking essential"
    },
    {
        img : "https://m.media-amazon.com/images/I/91kKqnkv9jL._AC_SY200_.jpg",
        discount : 52,
        DealOfDay : "Deal of the Day",
        desc : "TOP Deals on PUMA & Skechers footwear"
    },

    {
        img : "https://m.media-amazon.com/images/I/41fsUIG2fwL._AC_SY200_.jpg",
        discount : 12,
        DealOfDay : "Deal of the Day",
        desc : "Handpicked Intel Powered Laptops; High Performance"
    },
    {
        img : "https://m.media-amazon.com/images/I/317lhW5iHVL._AC_SY200_.jpg",
        discount : 65,
        DealOfDay : "Deal of the Day",
        desc : "Powerbank from Mi, Ambrane, URBN and more"
    },

    {
        img : "https://m.media-amazon.com/images/I/41yxd6A+ZAL._AC_SY200_.jpg",
        discount : 65,
        DealOfDay : "Deal of the Day",
        desc : "Top deals on Truke, Govo and more"
    },
    {
        img : "https://m.media-amazon.com/images/I/41wcMkODJLL._AC_SY200_.jpg",
        discount : 75,
        DealOfDay : "Deal of the Day",
        desc : "Amazing deals on pTron, Jabra, Portronics"
    },
    {
        img : "https://m.media-amazon.com/images/I/61QQtY6qtHL._AC_SY200_.jpg",
        discount : 82,
        DealOfDay : "Deal of the Day",
        desc : "Levi's, Allen Solly, ANNI DESIGNER, Janasya & more"
    },
    {
        img : "https://m.media-amazon.com/images/I/31aTPRvXiSL._AC_SY200_.jpg",
        discount : 77,
        DealOfDay : "Deal of the Day",
        desc : "Exciting  deals on Mivi, Wecool, Wings"
    },
    {
        img : "https://m.media-amazon.com/images/I/21wNUazPKRL._AC_SY200_.jpg",
        discount : 20,
        DealOfDay : "Deal of the Day",
        desc : "Never before deals on HP printers"
    },
    {
        img : "https://m.media-amazon.com/images/I/41bFnhrsyOL._AC_SY200_.jpg",
        discount : 19,
        DealOfDay : "Deal of the Day",
        desc : "Vivo Y75 - 18W fast charge, FHD plus display"
    },
    {
        img : "https://m.media-amazon.com/images/I/41wyFlObIrL._AC_SY200_.jpg",
        discount : "25",
        DealOfDay : "Deal of the Day",
        desc : "Nokia 5710 - newly launched 4G feature phone"
    },
    {
        img : "https://m.media-amazon.com/images/I/31Zq-alRH9L._AC_SY200_.jpg",
        discount : 32,
        DealOfDay : "Deal of the Day",
        desc : "Vacuum Cleaners from Top Brands"
    },



]