export const imageSlider = [
    {
        img : "https://rukminim1.flixcart.com/fk-p-flap/1688/280/image/68dad970da9c63c7.jpg?q=50",
        link : "https://www.flipkart.com/infinix-hot-20-play-aurora-green-64-gb/p/itm1e6903eb0203e?pid=MOBGK23WWFC8SUZZ&param=59886&otracker=hp_bannerads_1_2.bannerAdCard.BANNERADS_20%2BPlay_HUD5YVEMPWIO"
    },
    {
        img : "https://rukminim1.flixcart.com/fk-p-flap/3376/560/image/6c93de92458aa0c1.jpeg?q=50",
        link : "https://www.flipkart.com/6bo/b5g/~cs-ionqlb5ght/pr?sid=6bo%2Cb5g&collection-tab-name=Apple+MacBook&otracker=hp_bannerads_2_2.bannerAdCard.BANNERADS_Alt_44UZJMJ94YR3"
    },
    {
        img : "https://rukminim1.flixcart.com/fk-p-flap/3376/560/image/d02b3b49e4150abb.jpg?q=50",
        link : "https://www.flipkart.com/infinix-hot-20-5g-space-blue-64-gb/p/itm6646cdd2ff265?pid=MOBGK23W5QZQGSZW&param=547875&otracker=hp_bannerads_3_2.bannerAdCard.BANNERADS_Cat_Mob_HPW_Infinix%2BHot%2B20%2B5G_VHN6I1MV48BP"
    },
    {
        img : "https://rukminim1.flixcart.com/fk-p-flap/1688/280/image/c0bec65432fb07fc.jpg?q=50",
        link : "https://www.flipkart.com/travel/flights?param=FKDTHPWNOV22zerofeenmnvndghkskjsjbjn&otracker=hp_bannerads_4_2.bannerAdCard.BANNERADS_1_LLSGOIN663NS"
    },
    {
        img : "https://rukminim1.flixcart.com/flap/1688/280/image/75a15c3e19c3f7de.jpg?q=50",
        link : "https://www.flipkart.com/furniture-india-ka-furniture-store?otracker=hp_bannerads_5_2.bannerAdCard.BANNERADS_Furniture%2BBestsellers_ASPFJEKJRE57"
    }
]